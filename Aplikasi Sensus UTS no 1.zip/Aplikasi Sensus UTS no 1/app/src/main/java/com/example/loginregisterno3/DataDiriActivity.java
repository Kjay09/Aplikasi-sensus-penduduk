package com.example.loginregisterno3;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DataDiriActivity extends AppCompatActivity {

    private EditText namaEditText;
    private EditText AlamatEditText;
    private EditText KotaEditText;
    private EditText tanggalLahirEditText;
    private RadioGroup jkRadioGroup;
    private EditText UsiaEditText;
    private EditText PekerjaanEditText;
    private EditText GajiEditText;
    private RadioGroup statusRadioGroup;
    private EditText pendidikanEditText;
    private Button simpanButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_diri);

        // Inisialisasi view
        namaEditText = findViewById(R.id.namaEditText);
        AlamatEditText = findViewById(R.id.AlamatEditText);
        KotaEditText = findViewById(R.id.KotaEditText);
        tanggalLahirEditText = findViewById(R.id.tanggalLahirEditText);
        jkRadioGroup = findViewById(R.id.jkRadioGroup);
        UsiaEditText = findViewById(R.id.UsiaEditText);
        PekerjaanEditText = findViewById(R.id.PekerjaanEditText);
        GajiEditText = findViewById(R.id.GajiEditText);
        statusRadioGroup = findViewById(R.id.statusRadioGroup);
        pendidikanEditText = findViewById(R.id.pendidikanEditText);
        simpanButton = findViewById(R.id.simpanButton);


        // Set onClickListener untuk simpanButton
        simpanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ambil data dari view
                String nama = namaEditText.getText().toString();
                String alamat = AlamatEditText.getText().toString();
                String Kota = KotaEditText.getText().toString();
                String tanggalLahir = tanggalLahirEditText.getText().toString();
                String jk = ((RadioButton) findViewById(jkRadioGroup.getCheckedRadioButtonId())).getText().toString();
                String Usia = UsiaEditText.getText().toString();
                String Pekerjaan = PekerjaanEditText.getText().toString();
                String Gaji = GajiEditText.getText().toString();
                String status = ((RadioButton) findViewById(statusRadioGroup.getCheckedRadioButtonId())).getText().toString();
                String pendidikan = pendidikanEditText.getText().toString();

                // Validasi jika data tidak kosong
                if (!nama.isEmpty() && !jk.isEmpty() && !tanggalLahir.isEmpty() && !pendidikan.isEmpty()) {
                    // Simpan data ke SharedPreferences
                    SharedPreferences sharedPref = getSharedPreferences("data_diri", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putString("Nama", nama);
                    editor.putString("Alamat", alamat);
                    editor.putString("Kota", Kota);
                    editor.putString("tanggal_lahir", tanggalLahir);
                    editor.putString("jk", jk);
                    editor.putString("usia", Usia);
                    editor.putString("Pekerjaan", Pekerjaan);
                    editor.putString("Gaji",Gaji);
                    editor.putString("status", status);
                    editor.putString("pendidikan", pendidikan);
                    editor.apply();

                    // Tampilkan pesan sukses dan kembali ke halaman sebelumnya
                    Toast.makeText(DataDiriActivity.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(DataDiriActivity.this, "Harap isi semua data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
