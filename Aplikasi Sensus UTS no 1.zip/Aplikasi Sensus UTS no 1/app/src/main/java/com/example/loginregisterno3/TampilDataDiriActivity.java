package com.example.loginregisterno3;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class TampilDataDiriActivity extends AppCompatActivity {

    private ListView dataDiriListView;
    private Button kembaliButton;
    private List<String> dataDiriList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_data_diri);

        // Inisialisasi view
        dataDiriListView = findViewById(R.id.dataDiriListView);
        kembaliButton = findViewById(R.id.kembaliButton);

        // Ambil data dari SharedPreferences
        SharedPreferences sharedPref = getSharedPreferences("data_diri", Context.MODE_PRIVATE);

        String nama = sharedPref.getString("nama","");
        String alamat = sharedPref.getString("Alamat","");
        String Kota = sharedPref.getString("Kota","");
        String tanggalLahir = sharedPref.getString("tanggal_lahir", "");
        String jk = sharedPref.getString("jk", "");
        String Usia = sharedPref.getString("Usia", "");
        String Pekerjaan = sharedPref.getString("Pekerjaan", "");
        String Gaji = sharedPref.getString("Gaji", "");
        String status = sharedPref.getString("status", "");
        String pendidikan = sharedPref.getString("pendidikan", "");

        // Tambahkan data ke dalam list
        dataDiriList = new ArrayList<>();
        dataDiriList.add("Nama: " + nama);
        dataDiriList.add("Jenis Kelamin: " + jk);
        dataDiriList.add("Tanggal Lahir: " + tanggalLahir);
        dataDiriList.add("Pendidikan: " + pendidikan);

        // Set adapter untuk ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataDiriList);
        dataDiriListView.setAdapter(adapter);

        // Set onClickListener untuk kembaliButton
        kembaliButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kembali ke halaman sebelumnya
                finish();
            }
        });
    }
}